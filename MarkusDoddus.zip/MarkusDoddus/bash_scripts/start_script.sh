#!/usr/bin/env bash

PWD=$(zenity --password --title="Welcome to the Game Mark" --timeout=10)

if [ $1 ]; then
  if [ $1 -eq "help" ]; then
    echo "You need to know the password to start the game..."
    exit 0
  fi
else
  if [[ $PWD == "TheGame42069" ]]; then
    echo "Password Accepted"
    sleep 5
    python3  /home/steve/Desktop/Programming/MarkusDoddus/python_scripts/gatekeeper.py
  else
    echo "Wrong password!...Try again!"
    exit 0
  fi
fi

exit 0
