#!/usr/bin/env python3

from sys import argv
import base64

# This script encodes strings to base64.
# Wonder what this could be used for?

if len(argv) <= 1:
    print("Invalid Parameters....Need runtime password...[misconfigured...exec_runtime[2]]")
    print("<script> -help for help")
else:
    if str(argv[1]) == "help":
        print("This script encodes strings to base64...Maybe there is a place where base64 is needed?")
    else:
        password = str(argv[1])
        decoded_pwd = base64.b64encode(bytes(password, 'utf-8'))
        print(decoded_pwd.decode('utf-8'))
