#!/usr/bin/env python3

from sys import argv
import base64

# This script decodes base64 encoded strings.
# Wonder what this could be used for?

if len(argv) <= 1:
    print("Invalid Parameters....Need runtime password...[misconfigured...exec_runtime[1]]")
    print("<script> -help for help")
else:
    if str(argv[1]) == "help":
        print("This script decodes strings encoded in base64...Maybe there is a base64 encoded password somewhere?")
    else:
        password = str(argv[1])
        decoded_pwd = base64.b64decode(password)
        print(decoded_pwd.decode('utf-8'))
