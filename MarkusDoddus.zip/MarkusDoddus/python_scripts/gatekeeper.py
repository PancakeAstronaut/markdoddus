#!/usr/bin/env python3

import json
from requests import get
import time
from sys import argv


div = "-----------------------------------------"
name = "Mark Dodd"

with open('../data_references/data.json', 'r') as outfile:
    data_file = json.load(outfile)

help = data_file['help']
if len(argv) > 1:
    if str(argv[1]) == "help":
        print(help)
        exit(0)
    else:
        print("Invalid Parameter....Accepted Parameters: <help>")
else:
    print("This script does not process ecoding/decoding....Maybe there are tools for that somewhere?")
    print(div)
    print("Please pay attention and read carefully, you will need to answer some prompts...")
    print(div)
    print(div)
    print(div)
    password1 = input("Please enter the first password...")
    if password1 == "ultimateHacker_69420":
        api_link = "Stephen's Development API Registration Server"
        print("Registering system with [{}]...".format(api_link))
        time.sleep(4)
        ip = get('https://api.ipify.org').text
        print('Your Public IP Address: {}'.format(ip))
        steve_server = "stephenRootAuthority@73.130.106.170"
        print("Sending your IP information to Authority Server: {}".format(steve_server))
        time.sleep(4)
        print(div)
        print("New Root Authority Service Location: Harrisburg, Pennsylvania")
        print("Routing Authority Proxy Server Location: US Department of Defense Naval Installation, Mechanicsburg, Pennsylvania")
        print(div)
        ipt1 = input("{}...Do you accept these connections? [Y/y]es or [N/n]o: ".format(name))
        print(div)
        if ipt1 == "Y" or ipt1 == "y":
            print("Fuck yeah, Lemme get unpacked here...give me a few seconds")
            time.sleep(20)
            print("Alright, here we go!")
            print(div)
            password2 = input("Enter password: ")
            if password2 == "bGludXhfc3lzQWRtaW40MjA2OQ==":
                print("Now then...Lets get to the cool stuff...")
                print(div)
                print(div)
                print("Mark....")
                print("You learned a lot, but you have a lot to learn yet, same as me...")
                print("The only way to do that is to continue to play with code and networks")
                print("so that you can continue to learn how to do things...Computers will do")
                print("whatever you tell them to do, so this system here, holds endless possibilities.")
                print("I cannot tell you what to do, because I'm curious about things myself, but I will")
                print("tell you that with Linux, comes great power, and with great power comes with responsibility.")
                print("You have to pick and choose what you want to do very carefully. This is a loaded weapon.")
                print("You can create some amazing things, but you can also get into major trouble if misused.")
                print("The tools necessary to do major damage, incur wrathand the likes have been left off this system.")
                print("This is so you don't try anything dumb. But you're your own person, and youre going to make your")
                print("own decisions. You want to learn something pretty cool, and you were able to solve the puzzle, ")
                print("which means that you have the capacity to work in this environment. You'll fit right in. ")
                print("With that said, you have had a tough run at life, and you need to be given the opportunities")
                print("to get yourself somewhere cool. Well congrats because today I am going to give you a couple of things.")
                print("The first, is you need a reliable machine. What better way to do that than to use a machine you're")
                print("already comfortable with? Right, this system is now yours to create with. Cool right? Doesn't stop there.")
                print("You need tools to do the job right. You have Community editions of IDEs on your computer because the ")
                print("Professional editions cost over $400 a year per product. I pay almost $3000 a year for a rolling subscription")
                print("of these professional programming tools. I will give you access to my account so you know you'll always have")
                print("what you need to succeed. This computer has also been added to my personal cloud defense network.")
                print("Nobody will ever fuck with your system because they'll have to break through my CloudSec servers first. ")
                print("You will have access to anything you need and more with access to my network. You need a server instance?")
                print("Build it. You need a database? Build it. My resources are your resources. Just ask me for what you need.")
                print("To wrap it up see below for your reward synopsis...")
                print(div)
                print(data_file['terminal_msg_1'])
                print(data_file['terminal_msg_2'])
                print(data_file['terminal_msg_3'])
                print("Oh yeah and the MacBook is yours to do whatever with.")
                print(div)
                print("You're all set now bud....Let's do something cool.")
                exit("System successfully added to Stephen's CloudSec Cluster....System Registered with Product Authority Server..")
            else:
                print(div)
                print("Password not accepted...This needs to be base64 encoded..")
                print("Rolling back changes")
                time.sleep(4)
                print("Deregistering device from Authority Server")
                exit("Changes rolled back....Try Harder?")
        else:
            print("Input not accepted, Rolling back changes...")
            time.sleep(2)
            print("Deregistering device with Authority Server")
            exit("Changes Rolled back and discarded...Incident reported to Authority Server")
    else:
        print("Password not accepted....")
        print("Hint: Password will be decoded from base64, maybe there is a decoder somewhere?")
        exit(0)
